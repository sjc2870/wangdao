/*************************************************************************
 > File Name: ans4Test.cc
 > Author: SJC
 > Mail: 1123305914@qq.com 
 > Created Time: Wed 26 Jun 2019 01:16:50 AM PDT
 ************************************************************************/
#include "ans0.h"
#include<iostream>
using std::cout;
using std::endl;

int main(int argc,char* argv[]){
	Line l(1,2,3,4);
	l.print();
}

